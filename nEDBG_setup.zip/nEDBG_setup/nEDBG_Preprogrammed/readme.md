# Pre-Programmed nEDBG

## Summary
- Purpose: Pre-programmed nEDBG / PKoB nano
- Target:  SAMD21E18A
- Format:  Intel hex of flash content only
- User rows:
  - USER_WORD0: 0xD8E0C7FA
  - USER_WORD1: 0xFFFFFD5A


## Details

### Content
This image is to be programmed into a SAMD21E18A device for it to become an unprovisioned nEDBG.  It contains:
- bootloader
- application
- dummy config

#### Bootloader
The bootloader provided here is production-ready, and is not user-servicable.

#### Application
The application provided here is production-ready.  However it is user-upgradeable, so kit manufacturing process _may_ need to include firmware upgrade if new features or bugfixes are required for this purpose.

#### Config
The configuration provided here is _not production-ready_ and _must_ be replaced by a valid config during the kit manfacturing process.

### Usage
To make a nEDBG from a SAMD21:
1. Erase the device
1. Program and verify the entire hexfile contents to the device
1. Set the user row values

The device will from this point be accessible as a nEDBG / PKoB nano.

### Versioning
This distribution is versioned manually in build.gradle, with an incrementing build-number being appended by the build system during generation.
The same version string also appears in the name of the hex file.

To resolve from this version to component versions, navigate to the corresponding artifact version archived in the release repository here:

https://artifacts.microchip.com/artifactory/ivy-local-release/microchip/preprogrammed_nedbg/

Open the ivy xml and the input component versions are shown as dependencies.
