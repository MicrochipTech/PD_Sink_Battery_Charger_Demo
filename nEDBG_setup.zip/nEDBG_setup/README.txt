*** nEDBG_setup Directory Contents ***

board_provisioning directory
	configure_PD_SINK_nedbg.bat - Batch file for provisioning the boards.  Run the batch file with one argument,
				      a 20 character serial number (hex digits), to provision a board that has been 
				      programmed with the nEDBG firmware.

	*.xml - Configuration files for the board and device configuration sections of the provisioning structure.
	        Do not modify.

	Serial_Number_log.txt - A record of the serial numbers that have been used for provisioned boards.


nEDBG_Preprogrammed directory
	Contains the initial nEDBG firmware to be programmed prior to provisioning a board.

nEDBG_setup_procedure.docx
	Outline of the process of programming the nEDBG firmware and provisioning a board with a configuration
	structure and serial number.